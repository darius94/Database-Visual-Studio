﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DAL;

namespace TesterApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Employee _employee = new Employee();
            _employee.Name = txtEmpName.Text;
            _employee.Salary = Convert.ToDouble( txtEmpSalary.Text );

            EmployeeController _employeeController = new EmployeeController();
            _employeeController.WriteIntoDB(_employee);

            txtEmpName.Text = "";
            txtEmpSalary.Text = "";

            LoadData();

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            EmployeeController _employeeController = new EmployeeController();
            grdEmployee.DataSource = _employeeController.ReadFormDB();
        }
    }
}
