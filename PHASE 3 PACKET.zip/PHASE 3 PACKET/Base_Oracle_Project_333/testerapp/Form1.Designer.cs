﻿namespace TesterApp
{
    partial class customerServices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(customerServices));
            this.createCustomer = new System.Windows.Forms.Button();
            this.grdEmployee = new System.Windows.Forms.DataGridView();
            this.loadCustomer = new System.Windows.Forms.Button();
            this.customerID = new System.Windows.Forms.TextBox();
            this.lblEmpName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.TextBox();
            this.firstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.phone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.dob = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.vehicleDID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.empID = new System.Windows.Forms.TextBox();
            this.financeID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.VIN = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.deleteCusID = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.deleteCustomer = new System.Windows.Forms.Button();
            this.updateAddress = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.updatePhone = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnUpdateAddress = new System.Windows.Forms.Button();
            this.cusIDupdateAddress = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnUpdatePhone = new System.Windows.Forms.Button();
            this.cusIDupdatePhone = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdEmployee)).BeginInit();
            this.SuspendLayout();
            // 
            // createCustomer
            // 
            this.createCustomer.Location = new System.Drawing.Point(510, 473);
            this.createCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.createCustomer.Name = "createCustomer";
            this.createCustomer.Size = new System.Drawing.Size(136, 29);
            this.createCustomer.TabIndex = 0;
            this.createCustomer.Text = "Create Customer";
            this.createCustomer.UseVisualStyleBackColor = true;
            this.createCustomer.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // grdEmployee
            // 
            this.grdEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdEmployee.Location = new System.Drawing.Point(9, 11);
            this.grdEmployee.Margin = new System.Windows.Forms.Padding(2);
            this.grdEmployee.Name = "grdEmployee";
            this.grdEmployee.RowTemplate.Height = 28;
            this.grdEmployee.Size = new System.Drawing.Size(625, 206);
            this.grdEmployee.TabIndex = 2;
            // 
            // loadCustomer
            // 
            this.loadCustomer.Location = new System.Drawing.Point(510, 229);
            this.loadCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.loadCustomer.Name = "loadCustomer";
            this.loadCustomer.Size = new System.Drawing.Size(139, 29);
            this.loadCustomer.TabIndex = 3;
            this.loadCustomer.Text = "Load Customers";
            this.loadCustomer.UseVisualStyleBackColor = true;
            this.loadCustomer.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // customerID
            // 
            this.customerID.Location = new System.Drawing.Point(21, 229);
            this.customerID.Margin = new System.Windows.Forms.Padding(2);
            this.customerID.Name = "customerID";
            this.customerID.Size = new System.Drawing.Size(110, 20);
            this.customerID.TabIndex = 4;
            // 
            // lblEmpName
            // 
            this.lblEmpName.AutoSize = true;
            this.lblEmpName.Location = new System.Drawing.Point(42, 251);
            this.lblEmpName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmpName.Name = "lblEmpName";
            this.lblEmpName.Size = new System.Drawing.Size(65, 13);
            this.lblEmpName.TabIndex = 5;
            this.lblEmpName.Text = "Customer ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(203, 251);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Last Name";
            // 
            // lastName
            // 
            this.lastName.Location = new System.Drawing.Point(157, 229);
            this.lastName.Margin = new System.Windows.Forms.Padding(2);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(156, 20);
            this.lastName.TabIndex = 7;
            // 
            // firstName
            // 
            this.firstName.Location = new System.Drawing.Point(338, 229);
            this.firstName.Margin = new System.Windows.Forms.Padding(2);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(156, 20);
            this.firstName.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(385, 251);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "First Name";
            // 
            // phone
            // 
            this.phone.Location = new System.Drawing.Point(21, 293);
            this.phone.Margin = new System.Windows.Forms.Padding(2);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(156, 20);
            this.phone.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 315);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Phone (333-333-3333)";
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(204, 293);
            this.address.Margin = new System.Windows.Forms.Padding(2);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(290, 20);
            this.address.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(326, 315);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 376);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Email";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(21, 354);
            this.email.Margin = new System.Windows.Forms.Padding(2);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(240, 20);
            this.email.TabIndex = 16;
            // 
            // dob
            // 
            this.dob.Location = new System.Drawing.Point(286, 354);
            this.dob.Margin = new System.Windows.Forms.Padding(2);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(156, 20);
            this.dob.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(313, 376);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "DOB (12-MAR-2016)";
            // 
            // status
            // 
            this.status.Location = new System.Drawing.Point(464, 354);
            this.status.Margin = new System.Windows.Forms.Padding(2);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(30, 20);
            this.status.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(461, 376);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Status";
            // 
            // vehicleDID
            // 
            this.vehicleDID.Location = new System.Drawing.Point(21, 414);
            this.vehicleDID.Margin = new System.Windows.Forms.Padding(2);
            this.vehicleDID.Name = "vehicleDID";
            this.vehicleDID.Size = new System.Drawing.Size(156, 20);
            this.vehicleDID.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(51, 436);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Vehicle Dealer ID";
            // 
            // empID
            // 
            this.empID.Location = new System.Drawing.Point(204, 414);
            this.empID.Margin = new System.Windows.Forms.Padding(2);
            this.empID.Name = "empID";
            this.empID.Size = new System.Drawing.Size(156, 20);
            this.empID.TabIndex = 23;
            // 
            // financeID
            // 
            this.financeID.Location = new System.Drawing.Point(381, 414);
            this.financeID.Margin = new System.Windows.Forms.Padding(2);
            this.financeID.Name = "financeID";
            this.financeID.Size = new System.Drawing.Size(113, 20);
            this.financeID.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(238, 436);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Employee ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(404, 436);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Finance ID";
            // 
            // VIN
            // 
            this.VIN.Location = new System.Drawing.Point(21, 473);
            this.VIN.Margin = new System.Windows.Forms.Padding(2);
            this.VIN.Name = "VIN";
            this.VIN.Size = new System.Drawing.Size(290, 20);
            this.VIN.TabIndex = 27;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(141, 495);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "VIN";
            // 
            // deleteCusID
            // 
            this.deleteCusID.Location = new System.Drawing.Point(524, 280);
            this.deleteCusID.Margin = new System.Windows.Forms.Padding(2);
            this.deleteCusID.Name = "deleteCusID";
            this.deleteCusID.Size = new System.Drawing.Size(110, 20);
            this.deleteCusID.TabIndex = 29;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(546, 302);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 30;
            this.label12.Text = "Customer ID";
            // 
            // deleteCustomer
            // 
            this.deleteCustomer.Location = new System.Drawing.Point(510, 318);
            this.deleteCustomer.Name = "deleteCustomer";
            this.deleteCustomer.Size = new System.Drawing.Size(139, 29);
            this.deleteCustomer.TabIndex = 31;
            this.deleteCustomer.Text = "Delete Customer";
            this.deleteCustomer.UseVisualStyleBackColor = true;
            this.deleteCustomer.Click += new System.EventHandler(this.deleteCustomer_Click);
            // 
            // updateAddress
            // 
            this.updateAddress.Location = new System.Drawing.Point(206, 534);
            this.updateAddress.Margin = new System.Windows.Forms.Padding(2);
            this.updateAddress.Name = "updateAddress";
            this.updateAddress.Size = new System.Drawing.Size(290, 20);
            this.updateAddress.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(335, 556);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "Address";
            // 
            // updatePhone
            // 
            this.updatePhone.Location = new System.Drawing.Point(340, 593);
            this.updatePhone.Margin = new System.Windows.Forms.Padding(2);
            this.updatePhone.Name = "updatePhone";
            this.updatePhone.Size = new System.Drawing.Size(156, 20);
            this.updatePhone.TabIndex = 34;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(359, 615);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Phone (333-333-3333)";
            // 
            // btnUpdateAddress
            // 
            this.btnUpdateAddress.Location = new System.Drawing.Point(510, 529);
            this.btnUpdateAddress.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateAddress.Name = "btnUpdateAddress";
            this.btnUpdateAddress.Size = new System.Drawing.Size(136, 29);
            this.btnUpdateAddress.TabIndex = 36;
            this.btnUpdateAddress.Text = "Update Address";
            this.btnUpdateAddress.UseVisualStyleBackColor = true;
            this.btnUpdateAddress.Click += new System.EventHandler(this.btnUpdateAddress_Click);
            // 
            // cusIDupdateAddress
            // 
            this.cusIDupdateAddress.Location = new System.Drawing.Point(83, 534);
            this.cusIDupdateAddress.Margin = new System.Windows.Forms.Padding(2);
            this.cusIDupdateAddress.Name = "cusIDupdateAddress";
            this.cusIDupdateAddress.Size = new System.Drawing.Size(110, 20);
            this.cusIDupdateAddress.TabIndex = 37;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(106, 556);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "Customer ID";
            // 
            // btnUpdatePhone
            // 
            this.btnUpdatePhone.Location = new System.Drawing.Point(510, 588);
            this.btnUpdatePhone.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdatePhone.Name = "btnUpdatePhone";
            this.btnUpdatePhone.Size = new System.Drawing.Size(136, 29);
            this.btnUpdatePhone.TabIndex = 39;
            this.btnUpdatePhone.Text = "Update Phone";
            this.btnUpdatePhone.UseVisualStyleBackColor = true;
            this.btnUpdatePhone.Click += new System.EventHandler(this.btnUpdatePhone_Click);
            // 
            // cusIDupdatePhone
            // 
            this.cusIDupdatePhone.Location = new System.Drawing.Point(217, 593);
            this.cusIDupdatePhone.Margin = new System.Windows.Forms.Padding(2);
            this.cusIDupdatePhone.Name = "cusIDupdatePhone";
            this.cusIDupdatePhone.Size = new System.Drawing.Size(110, 20);
            this.cusIDupdatePhone.TabIndex = 40;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(240, 615);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 13);
            this.label16.TabIndex = 41;
            this.label16.Text = "Customer ID";
            // 
            // customerServices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 648);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cusIDupdatePhone);
            this.Controls.Add(this.btnUpdatePhone);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cusIDupdateAddress);
            this.Controls.Add(this.btnUpdateAddress);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.updatePhone);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.updateAddress);
            this.Controls.Add(this.deleteCustomer);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.deleteCusID);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.VIN);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.financeID);
            this.Controls.Add(this.empID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.vehicleDID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.address);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblEmpName);
            this.Controls.Add(this.customerID);
            this.Controls.Add(this.loadCustomer);
            this.Controls.Add(this.grdEmployee);
            this.Controls.Add(this.createCustomer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "customerServices";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Pro-Dealer  Customer Services";
            ((System.ComponentModel.ISupportInitialize)(this.grdEmployee)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button createCustomer;
        private System.Windows.Forms.DataGridView grdEmployee;
        private System.Windows.Forms.Button loadCustomer;
        private System.Windows.Forms.TextBox customerID;
        private System.Windows.Forms.Label lblEmpName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.TextBox dob;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox vehicleDID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox empID;
        private System.Windows.Forms.TextBox financeID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox VIN;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox deleteCusID;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button deleteCustomer;
        private System.Windows.Forms.TextBox updateAddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox updatePhone;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnUpdateAddress;
        private System.Windows.Forms.TextBox cusIDupdateAddress;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnUpdatePhone;
        private System.Windows.Forms.TextBox cusIDupdatePhone;
        private System.Windows.Forms.Label label16;
    }
}

