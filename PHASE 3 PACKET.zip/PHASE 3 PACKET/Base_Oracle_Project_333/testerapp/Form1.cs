﻿using System;
using System.Windows.Forms;
using DAL;

namespace TesterApp
{
    public partial class customerServices : Form
    {
        public customerServices()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Customer _customer = new Customer();
            _customer.ID = Convert.ToInt64(customerID.Text);
            _customer.lastName = Convert.ToString(lastName.Text);
            _customer.firstName = Convert.ToString(firstName.Text);
            _customer.phone = Convert.ToString(phone.Text);
            _customer.address = Convert.ToString(address.Text);
            _customer.email = Convert.ToString(email.Text);
            _customer.dob = Convert.ToDateTime(dob.Text);
            _customer.status = Convert.ToString(status.Text);
            _customer.dealerID = Convert.ToInt64(vehicleDID.Text);
            _customer.empID = Convert.ToInt64(empID.Text);
            _customer.vehicleVIN = Convert.ToString(VIN.Text);
            _customer.financeID = Convert.ToInt64(financeID.Text);

            CustomerController _customerController = new CustomerController();
            _customerController.WriteIntoDB(_customer);

            customerID.Text = "";
            lastName.Text = "";
            firstName.Text = "";
            phone.Text = "";
            address.Text = "";
            email.Text = "";
            dob.Text = "";
            status.Text = "";
            vehicleDID.Text = "";
            empID.Text = "";
            VIN.Text = "";
            financeID.Text = "";

            LoadData();

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            CustomerController _customerController = new CustomerController();
            grdEmployee.DataSource = _customerController.ReadFromDB();
        }

        private void deleteCustomer_Click(object sender, EventArgs e)
        {
            Customer _customer = new Customer();
            _customer.ID = Convert.ToInt64(deleteCusID.Text);

            CustomerController _customerController = new CustomerController();
            _customerController.DeleteFromDB(_customer);

            deleteCusID.Text = "";
             
            LoadData();
        }

        private void btnUpdateAddress_Click(object sender, EventArgs e)
        {
            Customer _customer = new Customer();
            _customer.ID = Convert.ToInt64(cusIDupdateAddress.Text);
            _customer.address = Convert.ToString(updateAddress.Text);

            CustomerController _customerController = new CustomerController();
            _customerController.UpdateAddressDB(_customer);

            cusIDupdateAddress.Text = "";
            updateAddress.Text = "";

            LoadData();
        }

        private void btnUpdatePhone_Click(object sender, EventArgs e)
        {
            Customer _customer = new Customer();
            _customer.ID = Convert.ToInt64(cusIDupdatePhone.Text);
            _customer.phone = Convert.ToString(updatePhone.Text);

            CustomerController _customerController = new CustomerController();
            _customerController.UpdatePhoneDB(_customer);

            cusIDupdatePhone.Text = "";
            updatePhone.Text = "";

            LoadData();
        }
    }
}
