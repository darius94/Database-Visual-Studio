﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAL
{
    public class Employee
    {
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
    }
}
