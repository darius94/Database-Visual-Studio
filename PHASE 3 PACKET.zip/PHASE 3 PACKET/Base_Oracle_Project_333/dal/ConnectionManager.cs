﻿using System;
using System.Data.OleDb;

namespace DAL
{
    public class ConnectionManager
    {
        protected OleDbConnection conn;

        public ConnectionManager()
        {
            try
            {
                conn = new OleDbConnection("Data Source= (DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = lora07-scan.columbusstate.edu)(PORT = 1521)))(CONNECT_DATA =(SERVICE_NAME = acad_taf.columbusstate.edu)));Persist Security Info=True; User ID=GROUP5_SPRING2016;Password=bgs87hr0;Provider=OraOLEDB.Oracle;");
            }
            
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
    }
}
