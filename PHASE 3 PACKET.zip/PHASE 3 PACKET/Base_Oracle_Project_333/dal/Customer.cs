﻿using System;

namespace DAL
{
    public class Customer
    {
        public Int64 ID { get; set; }
        public String lastName { get; set; }
        public String firstName { get; set; }
        public String phone { get; set; }
        public String address { get; set; }
        public String email { get; set; }
        public DateTime dob { get; set; }
        public String status { get; set; }
        public Int64 dealerID { get; set; }
        public Int64 empID { get; set; }
        public String vehicleVIN { get; set; }
        public Int64 financeID { get; set; }
    }
}
