﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;

namespace DAL
{
    public class CustomerController : ConnectionManager
    {
        public List<Customer> ReadFromDB()
        {
            List<Customer> customers = new List<Customer>();

            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            OleDbDataReader reader;

            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "select * from customer";

                reader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                while (reader.Read())
                {
                    Customer customer = new Customer();

                    customer.ID = Convert.ToInt64(reader["CUS_ID"]);
                    customer.lastName = Convert.ToString(reader["CUS_LNAM"]);
                    customer.firstName = Convert.ToString(reader["CUS_FNAM"]);
                    customer.phone = Convert.ToString(reader["CUS_PHON"]);
                    customer.address = Convert.ToString(reader["CUS_ADDR"]);
                    customer.email = Convert.ToString(reader["CUS_EMAL"]);
                    customer.dob = Convert.ToDateTime(reader["CUS_DOB"]);
                    customer.status = Convert.ToString(reader["CUS_STAT"]);
                    customer.dealerID = Convert.ToInt64(reader["VEH_DID"]);
                    customer.empID = Convert.ToInt64(reader["EMP_ID"]);
                    customer.vehicleVIN = Convert.ToString(reader["VEH_VIN"]);
                    customer.financeID = Convert.ToInt64(reader["FIN_ID"]);

                    customers.Add(customer);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }

            return customers;

        }

        public void WriteIntoDB(Customer customer)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            
            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "insert into customer (cus_id, cus_lnam, cus_fnam, cus_phon, cus_addr, cus_emal, cus_dob, cus_stat, veh_did, emp_id, veh_vin, fin_id) values (:cus_id, :cus_lnam, :cus_fnam, :cus_phon, :cus_addr, :cus_emal, :cus_dob, :cus_stat, :veh_did, :emp_id, :veh_vin, :fin_id)";
                cmd.Parameters.AddWithValue("301", customer.ID);
                cmd.Parameters.AddWithValue("Gateson", customer.lastName);
                cmd.Parameters.AddWithValue("Bill", customer.firstName);
                cmd.Parameters.AddWithValue("404-111-0000", customer.phone);
                cmd.Parameters.AddWithValue("5500 Baltic Ave Columbus,GA", customer.address);
                cmd.Parameters.AddWithValue("BillyG@whatever.com", customer.email);
                cmd.Parameters.AddWithValue("20-Dec-1955", customer.dob);
                cmd.Parameters.AddWithValue("M", customer.status);
                cmd.Parameters.AddWithValue("125643", customer.dealerID);
                cmd.Parameters.AddWithValue("12225648", customer.empID);
                cmd.Parameters.AddWithValue("22340878512385630", customer.vehicleVIN);
                cmd.Parameters.AddWithValue("12-DEC-16", customer.financeID);

                cmd.ExecuteNonQuery();

                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }          
        }

        public void DeleteFromDB(Customer customer)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();

            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "delete from customer where cus_id = :cus_id";
                cmd.Parameters.AddWithValue("301", customer.ID);

                cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }
        }

        public void UpdateAddressDB(Customer customer)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();

            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "update customer set cus_addr = :cus_address where cus_id = :cus_id ";
                cmd.Parameters.AddWithValue("4225 University Ave.", customer.address);
                cmd.Parameters.AddWithValue("301", customer.ID);

                cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }
        }

        public void UpdatePhoneDB(Customer customer)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();

            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "update customer set cus_phon = :cus_phone where cus_id = :cus_id ";
                cmd.Parameters.AddWithValue("333-555-7777", customer.phone);
                cmd.Parameters.AddWithValue("301", customer.ID);

                cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
