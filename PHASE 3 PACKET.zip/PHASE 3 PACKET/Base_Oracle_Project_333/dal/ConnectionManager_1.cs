﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;

namespace DAL
{
    public class ConnectionManager
    {
        protected OleDbConnection conn;

        public ConnectionManager()
        {
            try
            {
                conn = new OleDbConnection("Data Source= (DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = lora07-scan.columbusstate.edu)(PORT = 1521)))(CONNECT_DATA =(SERVICE_NAME = acad_taf.columbusstate.edu)));Persist Security Info=True; User ID=DEMO_SPRING2016;Password=pgr6ytx0;Provider=OraOLEDB.Oracle;");
            }
            
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
 
    }
}
