﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;

namespace DAL
{
    public class EmployeeController : ConnectionManager
    {
        public List<Employee> ReadFormDB()
        {
            List<Employee> employees = new List<Employee>();

            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            OleDbDataReader reader;

            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "select * from employee";

                reader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                while (reader.Read())
                {
                    Employee employee = new Employee();

                    employee.Id = Convert.ToInt64(reader["EMP_ID"]);
                    employee.Name = Convert.ToString(reader["EMP_NAME"]);
                    employee.Salary = Convert.ToDouble(reader["EMP_SALARY"]);

                    employees.Add(employee);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }

            return employees;

        }

        public void WriteIntoDB(Employee employee)
        {
            conn.Open();
            OleDbCommand cmd = new OleDbCommand();
            
            try
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "insert into Employee (emp_name, emp_salary) values (:empName , :empSal)";
                cmd.Parameters.AddWithValue("empName", employee.Name);
                cmd.Parameters.AddWithValue("empSal", employee.Salary);

                cmd.ExecuteNonQuery();

                
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                conn.Close();
            }          
        }
    }
}
